# Blackjack Web Game

Team 5: Jesus Gomez, Taymas Nguyen, Ian Hernandez, Arav Singh   
Class: CPSC-362-06-18393    
University: California State University, Fullerton  
Professor: Mehdi Peiravi    

A single-player blackjack game against the dealer, built with plain HTML, CSS, and JavaScript.

## How to play
1. Click the chips to place a bet, then press Deal.
2. You and the dealer each get two cards. One dealer card stays face down.
3. Hit to take another card, or Stand to keep your hand.
4. Get closer to 21 than the dealer without going over. Over 21 is a bust.
5. Number cards are worth their number, J/Q/K are 10, and an ace is 11 or 1.
6. A two-card 21 (blackjack) pays 3 to 2. Other wins pay 1 to 1, and ties return your bet.
7. The dealer draws, one card per second, until reaching 17 or more.
8. The wins and losses counters track your rounds. You start with $500.

## Table chat
The chat panel on the right helps while you play:
- `/rules` shows the rules, `/?` explains each button, `/help` lists commands, `/clear` clears the chat.
- Emoji commands work like Discord: `/heart` sends ❤️, `/fire /skull` sends 🔥 💀. `/emoji` sends a random one, and `/emojis` lists them all. The dealer answers with 1–3 random emojis.
- Quick-reply bubbles (Good luck!, Any tips?, You're cheating!, Let me win, etc.) send a message, and the dealer answers with one of a few pre-written replies chosen at random.
- "Any tips?" gives a hint based on your current hand and the dealer's face-up card.
- When a round ends, a separate "Round won / Round lost" message appears. It's a casual, slang parody of a gambler's bad inner voice ("next one is def a win trust"), with extra lines for win and loss streaks.

## Files
- index.html: page structure
- style.css: table, cards, chips, and buttons
- script.js: game logic
- chat.js: chat panel, commands, and dealer replies

## Run it
Open index.html in a browser. To publish: upload the files to a GitHub repo, then Settings > Pages > deploy from the main branch.
