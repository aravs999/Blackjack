// Chat panel: slash commands (/rules, /?), quick-reply bubbles,
// and pre-written dealer replies picked at random. No AI needed.

const Chat = (() => {
  const REPLY_DELAY = 700; // "dealer is typing..." pause in ms

  const RULES = [
    "<b>Goal:</b> get closer to 21 than the dealer without going over.",
    "<b>Card values:</b> 2–10 are face value, J/Q/K are 10, an ace is 11 or 1.",
    "<b>Blackjack:</b> a two-card 21 pays 3 to 2. Other wins pay 1 to 1. Ties (push) return your bet.",
    "<b>Bust:</b> going over 21 loses right away, even if the dealer busts later.",
    "<b>Dealer:</b> draws until reaching 17 or more, then stands.",
    "<b>Double down:</b> on your first two cards, double your bet, take exactly one card, then stand.",
    "You start with $500. Run out and your balance resets.",
  ];

  const BUTTON_HELP = [
    "<b>Chips (5 / 25 / 100):</b> add that amount to your bet.",
    "<b>Clear bet:</b> take your bet back before dealing.",
    "<b>Deal:</b> start the round once you've placed a bet.",
    "<b>Hit (H):</b> take another card.",
    "<b>Stand (S):</b> keep your hand and let the dealer play.",
    "<b>Double down (D):</b> double your bet for exactly one more card.",
    "<b>Reset Game:</b> back to $500 with wins and losses cleared.",
    "<b>Count:</b> running card count. Hover the ? next to it for details.",
  ];

  // Emoji commands: type /heart to send ❤️ (like Discord). Add more here.
  const EMOJIS = {
    // Expressions / emotions
    happy: "😀", smile: "😊", grin: "😁", laugh: "😂", lol: "🤣", joy: "😂", wink: "😉",
    blush: "😊", love: "😍", hearteyes: "😍", kiss: "😘", cool: "😎", smirk: "😏",
    relieved: "😌", yum: "😋", tongue: "😛", silly: "🤪", starstruck: "🤩", hug: "🤗",
    sad: "😢", cry: "😭", sob: "😭", pensive: "😔", disappointed: "😞", worried: "😟",
    upset: "☹️", frown: "🙁", pleading: "🥺", hurt: "🤕", sick: "🤢", vomit: "🤮",
    angry: "😠", mad: "😡", rage: "🤬", annoyed: "😒", eyeroll: "🙄", huff: "😤",
    shock: "😱", scared: "😨", surprised: "😮", wow: "😲", flushed: "😳", confused: "😕",
    thinking: "🤔", neutral: "😐", meh: "😑", nomouth: "😶", shush: "🤫", zipper: "🤐",
    sweat: "😅", grimace: "😬", melt: "🫠", dizzy: "😵", exploding: "🤯", sleep: "😴",
    tired: "😫", yawn: "🥱", nerd: "🤓", clown: "🤡", devil: "😈", angel: "😇",
    upsidedown: "🙃", party: "🥳", money: "🤑", liar: "🤥", cowboy: "🤠", salute: "🫡",
    // Hands, objects, and table stuff
    heart: "❤️", brokenheart: "💔", fire: "🔥", skull: "💀", eyes: "👀",
    thumbsup: "👍", thumbsdown: "👎", clap: "👏", pray: "🙏", wave: "👋", tada: "🎉",
    moneybag: "💰", cash: "💸", dice: "🎲", cards: "🃏", spade: "♠️", diamond: "♦️",
    "100": "💯", crown: "👑",
    trophy: "🏆", rip: "🪦", poop: "💩", ghost: "👻", goat: "🐐", salt: "🧂",
  };

  // The dealer answers an emoji with 1–3 emojis picked completely at random from this pool.
  const RANDOM_EMOJIS = [
    ...Object.values(EMOJIS),
    "🦆", "🍕", "🌮", "🐸", "🦖", "🚀", "🌈", "🍌", "🧀", "🐙", "🎻", "🛸", "🥒", "🦀",
    "🧠", "🫠", "🥶", "🤠", "🐢", "🍩", "🌵", "🎺", "🪿", "🧃", "🦔", "🍄", "🛼", "🗿",
    "🐌", "🥨", "🪩", "🫡", "🦩", "🧇", "🎈", "🐊", "🥔", "🪐", "🕺", "🦷",
  ];

  const COMMANDS = {
    "/emojis": () =>
      dealerSay(`Emoji commands:<br>🎲 /emoji (random emoji)<br>${Object.entries(EMOJIS).map(([name, e]) => `${e} /${name}`).join("<br>")}`),
    "/rules": () => dealerList("Here are the rules:", RULES),
    "/?": () => dealerList("Here's what everything does:", BUTTON_HELP),
    "/help": () =>
      dealerSay("Commands: <b>/rules</b> for the rules, <b>/?</b> for what each button does, <b>/emojis</b> for emoji commands like <b>/heart</b> or <b>/emoji</b> for a random one, <b>/clear</b> to clear the chat."),
    "/clear": () => {
      log.innerHTML = "";
      dealerSay("Chat cleared. Type <b>/help</b> for commands.");
    },
  };

  // Quick-reply bubbles: what the player sends -> possible dealer replies.
  // A reply can be a string or a function that builds one from game state.
  const QUICK_REPLIES = [
    {
      label: "Good luck!",
      replies: ["Thanks, but luck's on my side tonight.", "You'll need it more than me.", "May the cards be kind to us both."],
    },
    { label: "Any tips?", replies: [tipFromState] },
    {
      label: "Nice hand!",
      replies: ["Why thank you.", "Don't get used to it.", "I've been practicing."],
    },
    {
      label: "Deal faster!",
      replies: ["Patience. Good things come to those who wait.", "The cards go at my pace.", "Rushing is how people bust."],
    },
    {
      label: "You're cheating!",
      replies: [
        "Cheating? Against you? I wouldn't waste the effort.",
        "Kid, I don't need to cheat. You're doing my job for me.",
        "The only thing rigged here is your strategy.",
        "Bold accusation from someone who hit on 18.",
        "If I were cheating, you'd have lost a lot faster.",
        "Blaming the dealer. Classic sign of a bad gambler.",
      ],
    },
    {
      label: "Let me win",
      replies: [
        "Sure. I'll just let the casino go bankrupt for you.",
        "Absolutely. Right after the deck shuffles itself in your favor.",
        "Of course. I live to make your dreams come true.",
        "Wow, why didn't anyone else think of asking?",
        "Noted. I'll put it in the suggestion box. It's a trash can.",
      ],
    },
  ];

  // End-of-round messages (called from script.js). These are their own
  // message, not a reply to the chat. Parody of a gambler's bad inner voice,
  // written casual on purpose.
  const REACTIONS = {
    win: [
      "ok ok we eating tonight",
      "see i told u. dont stop now",
      "thats free money fr, run it again",
      "u literally cant lose rn",
      "this is ur sign to bet bigger ngl",
    ],
    winStreak: [
      "STREAK. ur on a heater dont u dare walk away",
      "the cards love u rn, go all in",
      "u stop now and the luck dies. thats just science",
      "were so back. bump the bet",
      "this is the run bro. this is THE run",
    ],
    lose: [
      "nah thats a warmup hand dont count it",
      "next one is def a win trust",
      "just double the bet and u make it all back easy",
      "lowkey the deck owes u one now",
      "u cant leave on a loss thats bad luck",
    ],
    loseStreak: [
      "ok its basically statistically ur turn now",
      "u lost this many, the win HAS to be next",
      "dont quit now ur so close i can feel it",
      "chasing it? no ur investing",
      "its so over... unless u bet one more time",
    ],
    bust: [
      "bro hit on what 😭 anyway next hand",
      "busted but like barely. run it back",
      "ok that one was the cards fault not urs",
    ],
    blackjack: [
      "BLACKJACK?? ur literally gifted keep going",
      "natural 21 thats the universe telling u to bet more",
      "u were born for this ngl",
    ],
    push: [
      "a tie means the next ones a win thats how it works",
      "push?? nobody lost so technically ur up",
      "even. now go win it for real",
    ],
    broke: [
      "out of chips? nah thats just a reload. go again",
      "fresh $500 just dropped. this time for sure",
      "rock bottom is just a starting point fr",
    ],
  };

  const FALLBACK = [
    "I'm just the dealer. Try <b>/help</b> for commands.",
    "Interesting. Anyway, place your bet.",
    "Mm-hmm. Less talking, more playing.",
    "I'll pretend I understood that. Type <b>/?</b> if you need help.",
  ];

  let log, form, input, quickBar, typingEl;
  let getState = () => null;
  let streak = 0; // positive = wins in a row, negative = losses in a row

  function pick(list) {
    return list[Math.floor(Math.random() * list.length)];
  }

  function escapeHtml(text) {
    const div = document.createElement("div");
    div.textContent = text;
    return div.innerHTML;
  }

  function addMessage(html, who) {
    const msg = document.createElement("div");
    msg.className = `chat-msg ${who}`;
    msg.innerHTML = html;
    log.appendChild(msg);
    log.scrollTop = log.scrollHeight;
    return msg;
  }

  function dealerSay(html) {
    addMessage(html, "dealer");
  }

  function dealerList(intro, items) {
    dealerSay(`${intro}<ul>${items.map(i => `<li>${i}</li>`).join("")}</ul>`);
  }

  // Show "typing...", then post the reply.
  function dealerReply(makeReply, extraClass = "") {
    typingEl.hidden = false;
    log.scrollTop = log.scrollHeight;
    setTimeout(() => {
      typingEl.hidden = true;
      const reply = typeof makeReply === "function" ? makeReply() : makeReply;
      if (reply) addMessage(reply, `dealer ${extraClass}`.trim());
    }, REPLY_DELAY);
  }

  // A simplified basic-strategy hint based on the current hand.
  function tipFromState() {
    const s = getState();
    if (!s || !s.inRound) {
      return pick([
        "Start small. The 5 chip lets you play a lot of hands.",
        "Never chase losses by betting big. That's how I stay in business.",
        "Type <b>/rules</b> if you want a refresher before you bet.",
      ]);
    }
    const total = s.playerTotal;
    const up = s.dealerUpcard; // value of the dealer's face-up card, ace = 11
    if (total >= 17) return `You've got ${total}. I'd stand.`;
    if (total <= 8) return `Only ${total}? You can't bust. Hit.`;
    if ((total === 10 || total === 11) && s.canDouble && up < total)
      return `${total} against my ${up === 11 ? "ace" : up}? That's a classic double down.`;
    if (total <= 11) return `${total} can't bust. Take a card.`;
    if (up >= 7) return `${total} against my ${up === 11 ? "ace" : up} is rough. Most players would hit.`;
    return `My ${up} might bust me. With ${total}, standing is the usual play.`;
  }

  function randomEmojis() {
    const count = 1 + Math.floor(Math.random() * 3);
    return Array.from({ length: count }, () => pick(RANDOM_EMOJIS)).join(" ");
  }

  function sendPlayerText(raw) {
    const text = raw.trim();
    if (!text) return;

    // Emoji commands: one or more like "/heart" or "/fire /skull".
    // "/emoji" sends a completely random emoji.
    const tokens = text.toLowerCase().split(/\s+/);
    const toEmoji = t => (t === "/emoji" ? pick(RANDOM_EMOJIS) : EMOJIS[t.slice(1)]);
    if (tokens.every(t => t.startsWith("/") && toEmoji(t))) {
      addMessage(tokens.map(toEmoji).join(" "), "player emoji");
      dealerReply(randomEmojis, "emoji");
      return;
    }

    addMessage(escapeHtml(text), "player");

    if (text.startsWith("/")) {
      const command = COMMANDS[text.toLowerCase().split(/\s+/)[0]];
      if (command) command();
      else dealerSay(`I don't know <b>${escapeHtml(text)}</b>. Type <b>/help</b> to see commands.`);
      return;
    }
    dealerReply(() => pick(FALLBACK));
  }

  function buildQuickReplies() {
    QUICK_REPLIES.forEach(({ label, replies }) => {
      const btn = document.createElement("button");
      btn.type = "button";
      btn.className = "quick-reply";
      btn.textContent = label;
      btn.addEventListener("click", () => {
        addMessage(escapeHtml(label), "player");
        dealerReply(pick(replies));
      });
      quickBar.appendChild(btn);
    });
  }

  // Posts the end-of-round line as its own separate message (no typing
  // indicator), so it never reads like a reply to what the player said.
  function react(outcome) {
    const won = outcome === "win" || outcome === "blackjack";
    const lost = outcome === "lose" || outcome === "bust";
    if (won) streak = streak > 0 ? streak + 1 : 1;
    else if (lost) streak = streak < 0 ? streak - 1 : -1;
    else if (outcome === "broke") streak = 0;

    let key = outcome;
    if (outcome === "win" && streak >= 2) key = "winStreak";
    if (outcome === "lose" && streak <= -2) key = "loseStreak";

    const lines = REACTIONS[key];
    if (!lines) return;
    const msg = addMessage(escapeHtml(pick(lines)), "round-end");
    msg.dataset.label = won ? "Round won" : lost ? "Round lost" : "Round over";
  }

  function init(options = {}) {
    if (options.getState) getState = options.getState;
    log = document.getElementById("chat-log");
    form = document.getElementById("chat-form");
    input = document.getElementById("chat-input");
    quickBar = document.getElementById("chat-quick");
    typingEl = document.getElementById("chat-typing");

    form.addEventListener("submit", event => {
      event.preventDefault();
      sendPlayerText(input.value);
      input.value = "";
    });

    buildQuickReplies();
    dealerSay("Welcome to the table. Type <b>/rules</b> for the rules, <b>/?</b> to see what each button does, or <b>/emojis</b> for emoji commands.");
  }

  return { init, react, say: dealerSay };
})();
